package com.example.actividadbotones

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val botonAzul = findViewById<Button>(R.id.BlueButton)
        val botonRojo = findViewById<Button>(R.id.RedButton)
        val botonVerde = findViewById<Button>(R.id.GreenButton)
        val botonMorado = findViewById<Button>(R.id.PurpleButton)
        val botonRosa = findViewById<Button>(R.id.PinkButton)
        val textoSuperior = findViewById<TextView>(R.id.textoSuperior)

        var textoCapturado:String = ""
        botonAzul.setOnClickListener{
            textoCapturado = findViewById<EditText>(R.id.textEdit).text.toString()
            textoSuperior.text = textoCapturado
            textoSuperior.setBackgroundColor(R.color.lightBlue)
        }

        botonRojo.setOnClickListener{
            textoCapturado = findViewById<EditText>(R.id.textEdit).text.toString()
            textoSuperior.text = textoCapturado
            textoSuperior.setBackgroundColor(R.color.lightRed)
        }

        botonVerde.setOnClickListener{
            textoCapturado = findViewById<EditText>(R.id.textEdit).text.toString()
            textoSuperior.text = textoCapturado
            textoSuperior.setBackgroundColor(R.color.lightGreen)
        }

        botonMorado.setOnClickListener{
            textoCapturado = findViewById<EditText>(R.id.textEdit).text.toString()
            textoSuperior.text = textoCapturado
            textoSuperior.setBackgroundColor(R.color.lightGreen)
        }

        botonRosa.setOnClickListener{
            textoCapturado = findViewById<EditText>(R.id.textEdit).text.toString()
            textoSuperior.text = textoCapturado
            textoSuperior.setBackgroundColor(R.color.lightGreen)
        }

    }

}